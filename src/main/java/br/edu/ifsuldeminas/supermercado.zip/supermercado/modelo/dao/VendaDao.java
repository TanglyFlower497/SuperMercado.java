package br.edu.ifsuldeminas.supermercado.modelo.dao;

import br.edu.ifsuldeminas.supermercado.entidade.Venda;
import br.edu.ifsuldeminas.supermercado.entidade.Cliente;
import br.edu.ifsuldeminas.supermercado.entidade.Funcionario;
import br.edu.ifsuldeminas.supermercado.entidade.FormaPagamento;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

public class VendaDao extends GenericoDAO<Venda> {

    public void salvar(Venda objVenda) {
        String sql = "INSERT INTO Venda(data, codigoCliente, codigoFuncionario, codigoFormaPagamento, total, desconto, observacao) VALUES(?,?,?,?,?,?,?)";
        save(sql, objVenda.getData(), objVenda.getCliente().getCodigoCliente(), objVenda.getFuncionario().getCodigoFuncionario(),
                objVenda.getFormaPagamento().getCodigoFormaPagamento(), objVenda.getTotal(), objVenda.getDesconto(), objVenda.getObservacao());
    }

    public void alterar(Venda objVenda) {
        String sql = "UPDATE Venda SET data=?, codigoCliente=?, codigoFuncionario=?, codigoFormaPagamento=?, total=?, desconto=?, observacao=? WHERE codVenda=?";
        save(sql, objVenda.getData(), objVenda.getCliente().getCodigoCliente(), objVenda.getFuncionario().getCodigoFuncionario(),
                objVenda.getFormaPagamento().getCodigoFormaPagamento(), objVenda.getTotal(), objVenda.getDesconto(), objVenda.getObservacao(), objVenda.getCodVenda());
    } 

    public void excluir(Venda objVenda) {
        String sql = "DELETE FROM Venda WHERE codVenda=?";
        save(sql, objVenda.getCodVenda());
    }

    public List<Venda> buscarTodasVendas() {
        String sql = "SELECT v.*, c.nomeCliente as nomeCliente, f.nomeFuncionario as nomeFuncionario, fp.descricaoFormaPagamento as descFormaPagamento " +
                     "FROM Venda v " +
                     "LEFT JOIN Cliente c ON v.codigoCliente = c.codigoCliente " +
                     "LEFT JOIN Funcionario f ON v.codigoFuncionario = f.codigoFuncionario " +
                     "LEFT JOIN FormaPagamento fp ON v.codigoFormaPagamento = fp.codigoFormaPagamento";
        return buscarTodos(sql, new VendaRowMapper());
    }

    public Venda buscarVendaPorId(int id) {
        String sql = "SELECT v.*, c.nomeCliente as nomeCliente, f.nomeFuncionario as nomeFuncionario, fp.descricaoFormaPagamento as descFormaPagamento " +
                     "FROM Venda v " +
                     "LEFT JOIN Cliente c ON v.codigoCliente = c.codigoCliente " +
                     "LEFT JOIN Funcionario f ON v.codigoFuncionario = f.codigoFuncionario " +
                     "LEFT JOIN FormaPagamento fp ON v.codigoFormaPagamento = fp.codigoFormaPagamento " +
                     "WHERE v.codVenda=?";
        return buscarPorId(sql, new VendaRowMapper(), id);
    }

    private static class VendaRowMapper implements RowMapper<Venda> {
        
        @Override
        public Venda mapRow(ResultSet rs) throws SQLException {
            Venda objVenda = new Venda();
            objVenda.setCodVenda(rs.getInt("codVenda"));
            objVenda.setData(rs.getDate("data"));
            objVenda.setTotal(rs.getDouble("total"));
            objVenda.setDesconto(rs.getDouble("desconto"));
            objVenda.setObservacao(rs.getString("observacao"));

            int codigoCliente = rs.getInt("codigoCliente");
            if (!rs.wasNull()) {
                Cliente cliente = new Cliente();
                cliente.setCodigoCliente(codigoCliente);
                cliente.setNomeCliente(rs.getString("nomeCliente"));
                objVenda.setCliente(cliente);
            }
            
            int codigoFuncionario = rs.getInt("codigoFuncionario");
            if (!rs.wasNull()) {
                Funcionario funcionario = new Funcionario();
                funcionario.setCodigoFuncionario(codigoFuncionario);
                funcionario.setNomeFuncionario(rs.getString("nomeFuncionario"));
                objVenda.setFuncionario(funcionario);
            }
            
            int codigoFormaPagamento = rs.getInt("codigoFormaPagamento");
            if (!rs.wasNull()) {
                FormaPagamento formaPagamento = new FormaPagamento();
                formaPagamento.setCodigoFormaPagamento(codigoFormaPagamento);
                formaPagamento.setDescricaoFormaPagamento(rs.getString("descFormaPagamento"));
                objVenda.setFormaPagamento(formaPagamento);
            }

            return objVenda;
        }
    }
}