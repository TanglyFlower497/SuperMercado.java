/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.edu.ifsuldeminas.supermercado.controlador;
        
import br.edu.ifsuldeminas.supermercado.entidade.Venda;
import br.edu.ifsuldeminas.supermercado.entidade.Cliente;
import br.edu.ifsuldeminas.supermercado.entidade.Funcionario;
import br.edu.ifsuldeminas.supermercado.entidade.FormaPagamento;
import br.edu.ifsuldeminas.supermercado.modelo.dao.VendaDao;
import br.edu.ifsuldeminas.supermercado.modelo.dao.ClienteDao;
import br.edu.ifsuldeminas.supermercado.modelo.dao.FuncionarioDao;
import br.edu.ifsuldeminas.supermercado.modelo.dao.FormaPagamentoDao;
import br.edu.ifsuldeminas.supermercado.servico.WebConstante;
import jakarta.servlet.*;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.sql.Date;
import java.util.List;
/**
 *
 * @author vcart
 */

@WebServlet(WebConstante.BASE_PATH + "/VendaControlador")
public class VendaControlador extends HttpServlet {

    String opcao="", codVenda="", data="", total="", desconto="", observacao="", vendaCliente="", vendaFuncionario="", vendaFormaPagamento="";

    Venda objVenda = new Venda();
    VendaDao objVendaDao = new VendaDao();
    ClienteDao objClienteDao = new ClienteDao();
    FuncionarioDao objFuncionarioDao = new FuncionarioDao();
    FormaPagamentoDao objFormaPagamentoDao = new FormaPagamentoDao();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        try {
            opcao = request.getParameter("opcao");

            if(opcao == null || opcao.isEmpty()){
                opcao = "cadastrar";
            }

            codVenda = request.getParameter("codVenda");
            data = request.getParameter("data");
            total = request.getParameter("total");
            desconto = request.getParameter("desconto");
            observacao = request.getParameter("observacao");
            vendaCliente = request.getParameter("vendaCliente");
            vendaFuncionario = request.getParameter("vendaFuncionario");
            vendaFormaPagamento = request.getParameter("vendaFormaPagamento");

            switch (opcao) {
                 case "abrir": 
                    encaminharPagina(request, response);
                    break;

                case "cadastrar":
                    cadastrar(request, response);
                    break;

                case "enviarAlterar":
                    enviarAlterar(request, response);
                    break;

                case "executarAlterar":
                    executarAlterar(request, response);
                    break;

                case "enviarExcluir":
                    enviarExcluir(request, response);
                    break;

                case "executarExcluir":
                    executarExcluir(request, response);
                    break;

                case "cancelar":
                    cancelar(request, response);
                    break;
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    protected void cadastrar(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        objVenda.setData(parseDate(data));
        objVenda.setTotal(Double.valueOf(total.replace(",", ".")));
        objVenda.setDesconto(Double.valueOf(desconto.replace(",", ".")));
        objVenda.setObservacao(observacao);
        objVenda.getCliente().setCodigoCliente(Integer.valueOf(vendaCliente));
        objVenda.getFuncionario().setCodigoFuncionario(Integer.valueOf(vendaFuncionario));
        objVenda.getFormaPagamento().setCodigoFormaPagamento(Integer.valueOf(vendaFormaPagamento));

        objVendaDao.salvar(objVenda);

        request.setAttribute("mensagem", "Venda cadastrada com sucesso!");
        encaminharPagina(request, response);
    }

    protected void encaminharPagina(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        List<Venda> listaVenda = objVendaDao.buscarTodasVendas();
        request.setAttribute("listaVenda", listaVenda);

        List<Cliente> listaCliente = objClienteDao.buscarTodos();
        request.setAttribute("listaCliente", listaCliente);
        
        List<Funcionario> listaFuncionario = objFuncionarioDao.buscarTodos();
        request.setAttribute("listaFuncionario", listaFuncionario);
        
        List<FormaPagamento> listaFormaPagamento = objFormaPagamentoDao.buscarTodos();
        request.setAttribute("listaFormaPagamento", listaFormaPagamento);

        RequestDispatcher rd = request.getRequestDispatcher("/CadastroVenda.jsp");
        rd.forward(request, response);
    }

    protected void enviarAlterar(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
            
        request.setAttribute("codVenda", codVenda);
        request.setAttribute("data", data);
        request.setAttribute("total", total);
        request.setAttribute("desconto", desconto);
        request.setAttribute("observacao", observacao);
        request.setAttribute("vendaCliente", vendaCliente);
        request.setAttribute("vendaFuncionario", vendaFuncionario);
        request.setAttribute("vendaFormaPagamento", vendaFormaPagamento);
        request.setAttribute("opcao", "executarAlterar");

        encaminharPagina(request, response);
    }

    protected void executarAlterar(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        objVenda.setCodVenda(Integer.valueOf(codVenda));
        objVenda.setData(parseDate(data));
        objVenda.setTotal(Double.valueOf(total.replace(",", ".")));
        objVenda.setDesconto(Double.valueOf(desconto.replace(",", ".")));
        objVenda.setObservacao(observacao);
        objVenda.getCliente().setCodigoCliente(Integer.valueOf(vendaCliente));
        objVenda.getFuncionario().setCodigoFuncionario(Integer.valueOf(vendaFuncionario));
        objVenda.getFormaPagamento().setCodigoFormaPagamento(Integer.valueOf(vendaFormaPagamento));

        objVendaDao.alterar(objVenda);

        request.setAttribute("opcao", "cadastrar");
        encaminharPagina(request, response);
    }

    protected void enviarExcluir(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        request.setAttribute("codVenda", codVenda);
        request.setAttribute("data", data);
        request.setAttribute("total", total);
        request.setAttribute("desconto", desconto);
        request.setAttribute("observacao", observacao);
        request.setAttribute("vendaCliente", vendaCliente);
        request.setAttribute("vendaFuncionario", vendaFuncionario);
        request.setAttribute("vendaFormaPagamento", vendaFormaPagamento);
        request.setAttribute("opcao", "executarExcluir");
        request.setAttribute("mensagem", "Clique em salvar para excluir");

        encaminharPagina(request, response);
    }

    protected void executarExcluir(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        objVenda.setCodVenda(Integer.valueOf(codVenda));
        objVendaDao.excluir(objVenda);

        request.setAttribute("opcao", "cadastrar");
        request.setAttribute("mensagem", "Venda excluída com sucesso");
        encaminharPagina(request, response);
    }

    protected void cancelar(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        request.setAttribute("codVenda", "0");
        request.setAttribute("data", "");
        request.setAttribute("total", "");
        request.setAttribute("desconto", "");
        request.setAttribute("observacao", "");
        request.setAttribute("vendaCliente", "");
        request.setAttribute("vendaFuncionario", "");
        request.setAttribute("vendaFormaPagamento", "");
        request.setAttribute("opcao", "cadastrar");

        encaminharPagina(request, response);
    }

    private Date parseDate(String valor) {
        if (valor == null || valor.isEmpty()) {
            return null;
        }
        return Date.valueOf(valor);
    }
}
